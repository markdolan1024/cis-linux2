/// GLOBAL VARIABLES


/// Functions move between pages on form file.


$('#ListForm').click(function(){

	location.href = 'forms.html';
});

$('#CreateForm').click(function(){

	location.href  = 'formCreate.html';
});

$('#EditForm').click(function(){

	location.href  = 'formEdit.html';
});

